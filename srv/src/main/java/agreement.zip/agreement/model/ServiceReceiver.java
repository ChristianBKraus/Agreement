package agreement.model;

public class ServiceReceiver {

}

package agreement.model;

public class ServiceAgreement {

}

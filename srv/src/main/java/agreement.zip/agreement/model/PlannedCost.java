package agreement.model;

public class PlannedCost {

}

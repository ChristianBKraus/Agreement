package agreement.service;

public class ValidationException extends Exception { 

}

package agreement.service;
import agreement.model.*;

public class Service implements ServiceInterface {

	@Override
	public void initialize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void validateServiceAgreement(ServiceAgreement agreement) throws ValidationException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void validateServiceReceiver(ServiceReceiver request) throws ValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void validatePlannedCost(PlannedCost cost) throws ValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void validate() throws ValidationException {
		
	}

}
